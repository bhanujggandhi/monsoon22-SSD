import React from "react";
import "./Chip.css";

const Chip = ({ label }) => <p className='chip'>{label}</p>;

export default Chip;
